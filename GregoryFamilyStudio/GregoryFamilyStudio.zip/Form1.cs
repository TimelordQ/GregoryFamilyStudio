﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Linq;

namespace GregoryFamilyStudio
{
    public partial class Form1 : Form
    {
        private const string startDirectory = "e:\\videos";
        private const string PATHCONSTANT = "-";
        private string sCurDir = "";

        public Form1()
        {
            InitializeComponent();

            sCurDir = startDirectory;
            refreshFiles();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.Top = 0;
            //picResizer.Height = 684; // Screen.PrimaryScreen.WorkingArea.Height;
            //picResizer.Top = ((Screen.PrimaryScreen.WorkingArea.Height - picResizer.Height) / 2);
            this.Left = 0;
            //picResizer.Width = 1218; // Screen.PrimaryScreen.WorkingArea.Width;
            //picResizer.Left = ((Screen.PrimaryScreen.WorkingArea.Width - picResizer.Width) / 2);
            
        }

        private void Form1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == Convert.ToChar(Keys.Escape))
                Application.Exit();
            else if (e.KeyChar == Convert.ToChar(Keys.Enter))
            {
                if (lvMain.SelectedItems[0].Tag == PATHCONSTANT)
                {
                    if (lvMain.SelectedItems[0].SubItems[0].Text == "..")
                        sCurDir = sCurDir.Substring(0, sCurDir.LastIndexOf('\\'));
                    else
                        sCurDir = sCurDir + '\\' + lvMain.SelectedItems[0].SubItems[0].Text;

                    refreshFiles();
                }

            }
        }

        private void Form1_KeyUp(object sender, KeyEventArgs e)
        {
            /*
            bool bChangedHW = false;

            if (e.KeyCode == Keys.Up || e.KeyCode == Keys.Down)
            {
                picResizer.Height = picResizer.Height + ((e.KeyCode == Keys.Up) ? 2 : -2);
                picResizer.Top = ((Screen.PrimaryScreen.WorkingArea.Height - picResizer.Height) / 2);
                bChangedHW = true;
            }
            else if (e.KeyCode == Keys.Left || e.KeyCode == Keys.Right)
            {
                picResizer.Width = picResizer.Width + ((e.KeyCode == Keys.Left) ? 2 : -2);
                picResizer.Left = ((Screen.PrimaryScreen.WorkingArea.Width - picResizer.Width) / 2);
                bChangedHW = true;
            }

            if (bChangedHW)
                lblSize.Text = String.Format("Width={0},Height={1}", picResizer.Width, picResizer.Height);
             * */
        }

    private void refreshFiles()
    {
        ListViewItem sI;

        lvMain.Items.Clear();
        if (sCurDir != startDirectory)
        {
            ListViewItem lvi = lvMain.Items.Add("..");
            lvi.ForeColor = Color.Green;
            lvi.Tag = PATHCONSTANT;
        }

        // Directories
        foreach( String sElement in Directory.GetDirectories( sCurDir ) )
        {
            String sCur = sElement.ToUpper().Substring(sElement.ToUpper().LastIndexOf('\\') + 1, sElement.Length - sElement.ToUpper().LastIndexOf('\\')-1);
            ListViewItem lvi = lvMain.Items.Add( sCur );
            lvi.ForeColor = Color.LightGreen;
            lvi.Tag = PATHCONSTANT;
        }
    
        foreach( String sElement in Directory.GetFiles( sCurDir, "*.mp4"  ) )
        {
            String sCur = sElement.Substring(sElement.ToUpper().LastIndexOf('\\') + 1, sElement.Length - sElement.ToUpper().LastIndexOf('\\')-1);
            String[] sAllItems = new String[2];
            sAllItems[0] = sCur;

            dynamic shellApp = Activator.CreateInstance(Type.GetTypeFromProgID("Shell.Application"));
            var folder = shellApp.NameSpace(Path.GetDirectoryName(sElement));
            var file = folder.ParseName(Path.GetFileName(sElement));
            string propertyValue = folder.GetDetailsOf(file, 27); // 27 represents a specific property, adjust as needed

            sAllItems[1] = propertyValue;
            ListViewItem lvi = new ListViewItem( sAllItems );
            lvMain.Items.Add(lvi);
            lvi.ForeColor = Color.White;
                //lvi.Tag = PATHCONSTANT;
        }

        lvMain.Items[0].Selected = true;
    /*
    ' Files
    Dim filename As String
    sElement = Dir(sCurDir & "\", vbNormal)
    While sElement <> ""
        Dim extension As String
        extension = Mid(sElement, Len(sElement) - 3)
        filename = Mid(sElement, 1, Len(sElement) - 4)
        If extension = ".mp4" Then
            Set sI = lvMain.ListItems.Add(, , filename)
            sI.ForeColor = vbWhite
            sI.SubItems(1) = getMediaLength(sCurDir & "\" & sElement)
        End If
        sElement = Dir
    Wend
         * */
    
    }
    }
}
